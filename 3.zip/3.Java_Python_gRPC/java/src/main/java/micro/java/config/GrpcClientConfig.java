package micro.java.config;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import micro.java.stocktrading.StockTradingServiceGrpc;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GrpcClientConfig {

  @Bean(destroyMethod = "shutdownNow")
  public ManagedChannel stockTradingChannel() {
    return ManagedChannelBuilder
        .forAddress("localhost", 9090) // host:port
        .usePlaintext() // or TLS
        .build();
  }

  @Bean
  public StockTradingServiceGrpc.StockTradingServiceBlockingStub stockTradingBlockingStub(
      ManagedChannel stockTradingChannel) {
    return StockTradingServiceGrpc.newBlockingStub(stockTradingChannel);
  }
}
