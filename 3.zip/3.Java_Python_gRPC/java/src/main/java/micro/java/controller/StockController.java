package micro.java.controller;

import java.util.Map;
import lombok.RequiredArgsConstructor;
import micro.java.stocktrading.StockRequest;
import micro.java.stocktrading.StockResponse;
import micro.java.stocktrading.StockTradingServiceGrpc;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/stock")
@RequiredArgsConstructor
public class StockController {

  private final StockTradingServiceGrpc.StockTradingServiceBlockingStub stub;

  @PostMapping("/price")
  public StockResponse getStockPrice(@RequestBody Map<String, String> req) {
    return stub.getStockPrice(
        StockRequest.newBuilder().setStockSymbol(req.get("stock_symbol")).build()
    );
  }

}
