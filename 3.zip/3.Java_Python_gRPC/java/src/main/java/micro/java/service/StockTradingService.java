package micro.java.service;

import io.grpc.stub.StreamObserver;
import lombok.RequiredArgsConstructor;
import micro.java.model.Stock;
import micro.java.repository.StockRepository;
import micro.java.stocktrading.StockRequest;
import micro.java.stocktrading.StockResponse;
import micro.java.stocktrading.StockTradingServiceGrpc;
import org.springframework.grpc.server.service.GrpcService;

@GrpcService
@RequiredArgsConstructor
public class StockTradingService extends StockTradingServiceGrpc.StockTradingServiceImplBase {

  private final StockRepository stockRepository;

  @Override
  public void getStockPrice(StockRequest request,
      StreamObserver<StockResponse> responseObserver) {

    String stockSymbol = request.getStockSymbol();
    Stock stockEntity = stockRepository.findByStockSymbol(stockSymbol);

    StockResponse stockResponse = StockResponse.newBuilder()
        .setStockSymbol(stockEntity.getStockSymbol())
        .setPrice(stockEntity.getPrice())
        .setTimestamp(stockEntity.getLastUpdated().toString())
        .build();

    responseObserver.onNext(stockResponse);
    responseObserver.onCompleted();
  }
}