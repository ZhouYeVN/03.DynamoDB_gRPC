import boto3

# --- Configuration ---
TABLE_NAME = "Items"
REGION = "us-east-1"

# For DynamoDB Local (change to your local endpoint)
dynamodb = boto3.client(
    "dynamodb",
    region_name=REGION,
    endpoint_url="http://localhost:8000",  # comment out if using real AWS
    aws_access_key_id="dummy",
    aws_secret_access_key="dummy"
)

# --- Create Table ---
def create_table():
    try:
        response = dynamodb.create_table(
            TableName=TABLE_NAME,
            KeySchema=[
                {"AttributeName": "id", "KeyType": "HASH"}  # Partition key
            ],
            AttributeDefinitions=[
                {"AttributeName": "id", "AttributeType": "S"}
            ],
            ProvisionedThroughput={
                "ReadCapacityUnits": 5,
                "WriteCapacityUnits": 5
            }
        )
        print(f"✅ Creating table {TABLE_NAME}...")
        dynamodb.get_waiter("table_exists").wait(TableName=TABLE_NAME)
        print("🚀 Table created successfully!")
        print(response)
    except dynamodb.exceptions.ResourceInUseException:
        print(f"⚠️ Table '{TABLE_NAME}' already exists.")
    except Exception as e:
        print(f"❌ Error creating table: {e}")

if __name__ == "__main__":
    create_table()
