// language: java
package com.example.demo.config;

import java.net.URI;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;

@Configuration
public class DynamoDBConfig {

  @Value("${aws.dynamodb.endpoint:}")
  private String dynamoDbEndpoint;

  @Value("${aws.dynamodb.region:us-east-1}")
  private String dynamoDbRegion;

  @Bean
  @Profile("local")
  public DynamoDbClient localDynamoDbClient() {
    return DynamoDbClient.builder()
        .region(Region.of(dynamoDbRegion))
        .endpointOverride(URI.create(dynamoDbEndpoint))
        .credentialsProvider(StaticCredentialsProvider.create(
            AwsBasicCredentials.create("dummy", "dummy")
        ))
        .build();
  }

  @Bean
  @Profile("!local")
  public DynamoDbClient awsDynamoDbClient() {
    return DynamoDbClient.builder()
        .region(Region.of(dynamoDbRegion))
        .credentialsProvider(DefaultCredentialsProvider.create())
        .build();
  }
}
