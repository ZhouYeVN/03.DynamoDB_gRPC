package com.example.demo.config;

import com.example.demo.model.Item;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisConfig {

  @Bean
  public RedisTemplate<String, Item> redisTemplate(RedisConnectionFactory connectionFactory) {
    RedisTemplate<String, Item> template = new RedisTemplate<>();
    template.setConnectionFactory(connectionFactory);

    // Key serializer
    template.setKeySerializer(new StringRedisSerializer());

    // Value serializer (JSON for Item)
    Jackson2JsonRedisSerializer<Item> serializer = new Jackson2JsonRedisSerializer<>(Item.class);
    template.setValueSerializer(serializer);

    template.setHashKeySerializer(new StringRedisSerializer());
    template.setHashValueSerializer(serializer);

    template.afterPropertiesSet();
    return template;
  }
}