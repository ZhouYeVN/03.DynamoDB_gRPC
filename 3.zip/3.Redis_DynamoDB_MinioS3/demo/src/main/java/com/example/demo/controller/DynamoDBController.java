package com.example.demo.controller;

import com.example.demo.model.Item;
import java.util.HashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.GetItemResponse;
import software.amazon.awssdk.services.dynamodb.model.PutItemRequest;
import software.amazon.awssdk.services.dynamodb.model.PutItemResponse;

@Slf4j
@RestController
@RequestMapping("/api/dynamodb")
@RequiredArgsConstructor
public class DynamoDBController {

  private final DynamoDbClient dynamoDbClient;

  @Value("${aws.dynamodb.table-name:}")
  private String dynamoTableName;

  @PostMapping
  public ResponseEntity<String> createItem(@RequestBody Item item) {
    Map<String, AttributeValue> itemValues = new HashMap<>();
    itemValues.put("id", AttributeValue.fromS(item.getId())); // required key
    itemValues.put("name", AttributeValue.fromS(item.getName()));
    itemValues.put("quantity", AttributeValue.fromN(String.valueOf(item.getQuantity())));

    PutItemRequest request = PutItemRequest.builder()
        .tableName(dynamoTableName)
        .item(itemValues)
        .build();

    try {
      PutItemResponse response = dynamoDbClient.putItem(request);
      return ResponseEntity.ok(response + "✅ Item added successfully: " + item.getId());
    } catch (DynamoDbException e) {
      System.err.println("❌ Failed to add item: " + e.getMessage());
      throw e;
    }
  }

  @GetMapping("/{id}")
  public ResponseEntity<Item> getItem(@PathVariable String id) {
    GetItemRequest request = GetItemRequest.builder()
        .tableName(dynamoTableName)
        .key(Map.of("id", AttributeValue.fromS(id)))
        .build();

    GetItemResponse response = dynamoDbClient.getItem(request);

    if (!response.hasItem() || response.item().isEmpty()) {
      return ResponseEntity.notFound().build();
    }

    Map<String, AttributeValue> itemMap = response.item();

    Item item = new Item(); // required key
    item.setId(itemMap.get("id").s());
    item.setName(itemMap.containsKey("name") ? itemMap.get("name").s() : null);
    item.setQuantity(itemMap.containsKey("quantity") ? Integer.parseInt(itemMap.get("quantity").n()) : 0);

    return ResponseEntity.ok(item);
  }
}