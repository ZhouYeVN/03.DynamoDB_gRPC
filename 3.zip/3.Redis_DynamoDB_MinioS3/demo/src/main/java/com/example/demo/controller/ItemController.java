package com.example.demo.controller;

import com.example.demo.model.Item;
import com.example.demo.service.ItemService;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

@Slf4j
@RestController
@RequestMapping("/api/items")
@RequiredArgsConstructor
public class ItemController {

  private final ItemService itemService;

  @PostMapping
  public ResponseEntity<Void> createItem(@RequestBody Item item) {
    itemService.saveItem(item);
    return ResponseEntity.ok().build();
  }

//  @GetMapping("/{id}")
//  public ResponseEntity<Item> getItem(@PathVariable String id) {
//    Optional<Item> item = itemService.getItem(id);
//    return item.map(ResponseEntity::ok)
//        .orElse(ResponseEntity.notFound().build());
//  }

  @PostMapping("/add")
  public ResponseEntity<Void> addItem() {
    itemService.addItem("123", "Sample Item", "Sample Category");
    return ResponseEntity.ok().build();
  }

  @GetMapping("test/{id}")
  public ResponseEntity<String> testDynamoDBAccess(@PathVariable String id) {
    log.debug("Testing DynamoDB access for id: {}", id);
    var result = itemService.testDynamoDBAccess(id);
    return ResponseEntity.ok(result.toString());
  }

  @GetMapping("/hello")
  public ResponseEntity<String> testHello() {
    return ResponseEntity.ok("Hello World");
  }
}


