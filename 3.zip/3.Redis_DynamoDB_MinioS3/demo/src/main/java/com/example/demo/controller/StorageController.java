package com.example.demo.controller;

import com.example.demo.service.ObjectStorageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/storage")
@RequiredArgsConstructor
public class StorageController {

  private final ObjectStorageService storageService;

  @PostMapping("/upload/{key}")
  public ResponseEntity<Void> upload(@PathVariable String key, @RequestBody String content) {
    storageService.uploadObject(key, content);
    return ResponseEntity.ok().build();
  }

  @GetMapping("/download/{key}")
  public ResponseEntity<String> download(@PathVariable String key) {
    String content = storageService.downloadObjectAsString(key);
    return ResponseEntity.ok(content);
  }
}
