package com.example.demo.service;

import com.example.demo.model.Item;
import java.util.HashMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.time.Duration;
import java.util.Map;
import java.util.Optional;

import static java.util.Map.entry;

@Service
@RequiredArgsConstructor
@Slf4j
public class ItemService {

  private static final String TABLE_NAME = "Items";

  private final DynamoDbClient dynamoDbClient;
  private final RedisTemplate<String, Item> redisTemplate;

  @Value("${app.cache.ttl-seconds:600}")
  private long cacheTtlSeconds;

  public void addItem(String itemId, String name, String category) {
    if (itemId == null || itemId.isBlank()) {
      throw new IllegalArgumentException("itemId cannot be null or blank");
    }

    Map<String, AttributeValue> itemValues = new HashMap<>();
    itemValues.put("itemId", AttributeValue.fromS(itemId)); // required key
    itemValues.put("name", AttributeValue.fromS(name == null ? "" : name));
    itemValues.put("category", AttributeValue.fromS(category == null ? "" : category));

    PutItemRequest request = PutItemRequest.builder()
        .tableName(TABLE_NAME)
        .item(itemValues)
        .build();

    try {
      PutItemResponse response = dynamoDbClient.putItem(request);
      System.out.println("✅ Item added successfully: " + itemId);
    } catch (DynamoDbException e) {
      System.err.println("❌ Failed to add item: " + e.getMessage());
      throw e;
    }
  }

  public Map<String, AttributeValue>  testDynamoDBAccess(String id){
    GetItemRequest request = GetItemRequest.builder()
        .tableName(TABLE_NAME)
        .key(Map.of("itemId", AttributeValue.fromS(id)))
        .build();

    GetItemResponse response = dynamoDbClient.getItem(request);

    if (!response.hasItem() || response.item().isEmpty()) {
      return null; // or throw custom exception
    }

    return response.item();
  }

//  public Optional<Item> getItem(String id) {
//    log.debug("Fetching item with id: {}", id);
//
//    // 1. Try cache
//    Item cached = redisTemplate.opsForValue().get(id);
//    if (cached != null) {
//      log.debug("Cache HIT for id: {}", id);
//      return Optional.of(cached);
//    }
//
//    log.debug("Cache MISS for id: {}", id);
//
//    // 2. Read from DynamoDB
//    try {
//      GetItemResponse response = dynamoDbClient.getItem(GetItemRequest.builder()
//          .tableName(TABLE_NAME)
//          .key(Map.of("id", AttributeValue.builder().s(id).build()))
//          .build());
//
//      if (response.hasItem()) {
//        Map<String, AttributeValue> itemMap = response.item();
//        String name = itemMap.get("name") != null ? itemMap.get("name").s() : null;
//        String data = itemMap.get("data") != null ? itemMap.get("data").s() : null;
//
//        Item item = new Item(id, name, data);
//
//        // 3. Write to cache (cache-aside)
//        redisTemplate.opsForValue().set(id, item, Duration.ofSeconds(cacheTtlSeconds));
//        log.debug("Loaded from DB and cached item: {}", id);
//        return Optional.of(item);
//      } else {
//        log.debug("Item not found in DB: {}", id);
//        return Optional.empty();
//      }
//    } catch (Exception e) {
//      log.error("Error reading from DynamoDB", e);
//      throw new RuntimeException("Failed to retrieve item", e);
//    }
//  }

  public void saveItem(Item item) {
    String id = item.getId();
    log.debug("Saving item with id: {}", id);

    // 1. Write to DynamoDB
    try {
      Map<String, AttributeValue> itemMap = Map.ofEntries(
          entry("id", AttributeValue.builder().s(item.getId()).build()),
          entry("name", AttributeValue.builder().s(item.getName()).build())
//          entry("data", AttributeValue.builder().s(item.getQuantity()).build())
      );

      dynamoDbClient.putItem(PutItemRequest.builder()
          .tableName(TABLE_NAME)
          .item(itemMap)
          .build());

      log.debug("Saved to DynamoDB: {}", id);
    } catch (Exception e) {
      log.error("Error writing to DynamoDB", e);
      throw new RuntimeException("Failed to save item", e);
    }

    // 2. Update cache (write-through)
    redisTemplate.opsForValue().set(id, item, Duration.ofSeconds(cacheTtlSeconds));
    log.debug("Updated cache for item: {}", id);
  }
}