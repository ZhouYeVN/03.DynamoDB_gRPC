package com.example.demo.service;

import java.nio.file.Path;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Object;

@Service
@RequiredArgsConstructor
@Slf4j
public class ObjectStorageService {

  private final S3Client s3Client;

  @Value("${app.storage.bucket}")
  private String bucketName;

  public void uploadObject(String key, String content) {
    log.info("Uploading object with key: {} to bucket: {}", key, bucketName);
    s3Client.putObject(
        PutObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .build(),
        RequestBody.fromString(content)
    );
  }

  public String downloadObjectAsString(String key) {
    log.info("Downloading object with key: {} from bucket: {}", key, bucketName);

    ResponseBytes<GetObjectResponse> objectBytes = s3Client.getObjectAsBytes(
        GetObjectRequest.builder()
            .bucket(bucketName)
            .key(key)
            .build()
    );

    return objectBytes.asUtf8String();
  }

  public List<S3Object> listObjects() {
    var response = s3Client.listObjectsV2(req -> req.bucket(bucketName));
    return response.contents();
  }
}